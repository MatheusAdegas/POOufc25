from conta import Conta
from banco import BancoLista

banco = BancoLista()
conta1 = Conta(1, "João", 1000)
conta2 = Conta(2, "Maria", 2000)

banco.adicionar_conta(conta1)
banco.adicionar_conta(conta2)

conta1.creditar(500)
conta1.transferir(conta2, 200)

print(conta1.saldo)
print(conta2.saldo)