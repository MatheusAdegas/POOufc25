class Conta:
  def __init__(self, numero, titular, saldo):
    self.numero = numero
    self.titular = titular
    self.saldo = saldo

  def creditar(self, valor):
    self.saldo += valor

  def debitar(self, valor):
    self.saldo -= valor
    if self.saldo < 0:
      self.saldo = 0

  def transferir(self, conta_destino, valor):
    self.debitar(valor)
    conta_destino.creditar(valor)